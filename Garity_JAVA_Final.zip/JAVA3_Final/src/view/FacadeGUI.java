package view;

import model.Student;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import controller.MainController;
/**
 * Works with main controller to swap between different panes and display the correct screen
 * in 'MainView'. 
 * 
 * @author James Garity
 *
 */
public class FacadeGUI {

	private LoginScreen loginScreen = new LoginScreen();
	private SearchStudentScreen searchScreen = new SearchStudentScreen();
	private SainDisplayScreen sainScreen = new SainDisplayScreen();
	private SideOptions sideOptions = new SideOptions();
	private SainEditPage sainEditScreen = new SainEditPage();
	private AddStudentPage addStudentScreen = new AddStudentPage();
	private WhatIfScreen whatIfScreen = new WhatIfScreen();
	private Label popUpLabel = new Label();
	Pane pane = new Pane();
	Button continueButton;
	MainView view;
	MainController controller;
	Student myStudent;
	Scene popUp1 = new Scene(popUpLabel, 250, 200);
	
	/**
	 * 
	 * @param view - the MainView object created in 'Main'
	 * @param controller - the MainController object created in 'Main'
	 */
	public FacadeGUI(MainView view, MainController controller) {
		this.view = view;
		this.controller = controller;
	}

	public void setLoginView() {

		pane.getChildren().add(loginScreen.getMyGrid());
		continueButton = loginScreen.getContinueButton();
		
		// Controller checks for existing login data when login button is clicked
		loginScreen.b1.setOnAction(e -> {
			controller.loginClicked(loginScreen.getUserName(),
					loginScreen.getPassword());
		});
		

		

		loginScreen.saveButton.setOnAction(e->{
			controller.writeStudentSaveData();
			controller.writeStaffSaveData();
		});
		loginScreen.loadButton.setOnAction(e->{
			controller.loadStudentSaveData();
			controller.loadStaffSavedData();
		});
		
		//sets the login screen gui to MainView object

		view.setNewView(pane);
	}
	
	public void setSearchView() {
		pane.getChildren().clear();

		pane.getChildren().add(searchScreen.getMyGrid());
		pane.getChildren().add(addStudentScreen.getMyGrid());

		// the search and add student screens are on the same pane, their
		// visibilities are just swapped
		addStudentScreen.hide();

		searchScreen.viewSain.setOnAction(e -> {

			controller.viewSearchedSain();
		});
		
		//When 'Search Button' is clicked, controller handles results display.
		searchScreen.b1.setOnAction(e -> {
			searchScreen.hideViewSain();
			
			//make sure that user entered a valid student id into the given search field.
			try {
				controller.searchClicked(Integer.parseInt((searchScreen.search
						.getText())));
			
			} catch (NumberFormatException e1) {
				makeDoesNotExistWindow();
			}

		});
		searchScreen.addStudent.setOnAction(e2 -> {
			controller.addStudentViewClicked();
		});

		view.setNewView(pane);
	}
	/**
	 * Opens up the Edit Sain view, which swaps visibility of both a 
	 * 'Remove Courses' page and an 'Add Courses' page. It begins with 
	 * the 'Add Courses' page.
	 * 
	 * @param thisStudent - The student that the admin has searched.
	 */
	public void setEditSainView(Student thisStudent) {
		sainScreen.hide();
		sainEditScreen.show();
		sainEditScreen.hideGradeOption();

		sainEditScreen.addCourseButton.setOnAction(e -> {
			controller.addCourseClicked(thisStudent);
		});
		sainEditScreen.removeButton.setOnAction(e -> {
			controller.removeCourseClicked();
		});

		sainEditScreen.backToSain.setOnAction(e3 -> {
			controller.backToSainClicked();
		});

		// Option to alter grade only appears if NOT a current course
		sainEditScreen.notCurrentlyTaking.setOnAction(e1 -> {
			sainEditScreen.showGradeOption();
		});
		sainEditScreen.currentlyTaking.setOnAction(e2 -> {
			sainEditScreen.hideGradeOption();
		});

		// switch between two edit screens:
		sainEditScreen.addDisplayButton.setOnAction(e4 -> {
			sainEditScreen.hideRemovePage();
			sainEditScreen.show();
		});
		sainEditScreen.removeDisplayButton.setOnAction(e5 -> {
			sainEditScreen.hide();
			sainEditScreen.showRemovePage();
		});
	}
	/**
	 * 
	 * @param s - the toString that was given after finding a student with
	 * a matching id number to that searched, in the StudentBag.
	 */
	public void setSearchResults(String s) {
		searchScreen.results.setText(s);
		searchScreen.showViewSain();
	}
	/**
	 * Sets screen full of several text areas displaying the various courses
	 * on the given student's record in the right spot.
	 * 
	 * @param forThisStudent - the searched or logged in student.
	 */
	public void setSainView(Student forThisStudent) {

		sainScreen.setInfo(forThisStudent);
		pane.getChildren().clear();
		pane.getChildren().add(sainScreen.getMyGrid());
		pane.getChildren().add(whatIfScreen.getMyGrid());
		pane.getChildren().add(sainEditScreen.getMyGrid(forThisStudent));

		sainEditScreen.hide();
		whatIfScreen.hide();

		// "Update" button visible if user is admin:
		if (view.getStaffValue() == 2)
			sainScreen.update.setVisible(true);

		sainScreen.update.setOnAction(e -> {
			controller.updateSainClicked();
		});
		
		//Action to follow if "What-If?" Button is clicked on.
		sainScreen.b1.setOnAction(e -> {
			controller.whatIfClicked();
		});
		view.setNewView(pane);
	}
	
	public void setWhatIfView() {
		sainScreen.hide();
		whatIfScreen.show();
		
		//controller generates a new SAIN(with new major involved) when 'View New Sain' Button is clicked
		whatIfScreen.newSainButton.setOnAction(e -> {
			controller.newSainButtonClicked();
		});
	}
	/**
	 * 
	 */
	public void setAddStudentView() {
		searchScreen.hide();
		addStudentScreen.show();
		addStudentScreen.add.setOnAction(e -> {
					Boolean canContinue = true;
					
					//check to see if the given GPA value is a number
					try {
						Double.parseDouble(addStudentScreen.gpa.getText()
								.trim());
					} catch (NumberFormatException e1) {
						System.out.println(addStudentScreen.gpa.getText()
								.trim() + "issue");
						makeWrongGpaInputWindow();
						canContinue = false;
					}
					if (canContinue) {
						//Check to see if given GPA value is between 0 and 4.
						if (Double.parseDouble(addStudentScreen.gpa.getText()) <= 4
								&& Double.parseDouble(addStudentScreen.gpa
										.getText()) > 0) {
							controller.addStudentClicked();
						} else
							makeWrongGpaInputWindow();
					}

				});

	}

	public AddStudentPage getAddStudentPage() {
		return addStudentScreen;
	}

	public SearchStudentScreen getSearchScreen() {
		return searchScreen;
	}

	public WhatIfScreen getWhatIfScreen() {
		return whatIfScreen;
	}

	public SainDisplayScreen getSainScreen() {
		return sainScreen;
	}

	public SainEditPage getEditSainScreen() {
		return sainEditScreen;
	}

	public Pane getPane() {
		return pane;
	}

	public Button getContinueButton() {
		return continueButton;
	}

	/**
	 * Pop up window is created if the given id value for a searched 
	 * student does not exist.
	 */
	public void makeDoesNotExistWindow() {
		if (popUp1.getRoot().equals("Could not find account") == false) {
			popUpLabel.setText("Could not find account");
			popUp1.setRoot(popUpLabel);
		}
		Stage popUpStage = new Stage();
		view.makeDoesNotExistWindow(popUpStage, popUp1);
	}
	/**
	 * Pop up window is created if the given id value for a major 
	 * when adding a new student
	 */
	public void makeWrongMajorInputWindow() {
		if (popUp1.getRoot().equals("Not a valid input for Major ID") == false) {
			popUpLabel.setText("Not a valid input for Major ID");
			popUp1.setRoot(popUpLabel);
		}
		Stage popUpStage = new Stage();
		view.makeDoesNotExistWindow(popUpStage, popUp1);
	}
	/**
	 * Pop up window created when Administrator doesn't enter a GPA between 0 and 4
	 * when creating a new student.
	 */
	public void makeWrongGpaInputWindow() {
		if (popUp1.getRoot().equals(
				"Please enter a number between \n 0.0 and 4.0 for GPA") == false) {
			popUpLabel
					.setText("Please enter a number between \n 0.0 and 4.0 for GPA");
			popUp1.setRoot(popUpLabel);
		}
		Stage popUpStage = new Stage();
		view.makeDoesNotExistWindow(popUpStage, popUp1);
	}
	/**
	 * Pop up created to let Admin know that they have successfully created a new student and gives 
	 * Admin the id of new student.
	 * 
	 * @param studentId - the student id of the newest student created(the last position of a student in the student bag)
	 */
	public void createdNewStudentWindow(int studentId) {
		if (popUpLabel.getText().equals(
				"Student has been created with an id number of: " + studentId) == false) {
			popUpLabel
					.setText("Student has been created with an id number of: "
							+ studentId);
			popUp1.setRoot(popUpLabel);
		}

		Stage popUpStage = new Stage();
		view.makeDoesNotExistWindow(popUpStage, popUp1);
	}
	/**
	 * Pop up window created to show admin they have successfully added a course to the searched student's record
	 */
	public void addedNewCourseWindow() {
		if (popUpLabel.getText().equals(
				"New Course has been added to student's SAIN") == false) {
			popUpLabel.setText("New Course has been added to student's SAIN");
			popUp1.setRoot(popUpLabel);
		}
		Stage popUpStage = new Stage();
		view.makeDoesNotExistWindow(popUpStage, popUp1);
	}

	public void courseAlreadyExistsWindow() {
		if (popUpLabel.getText().equals(
				"This course already exists in student's SAIN") == false) {
			popUpLabel.setText("This course already exists in student's SAIN");
			popUp1.setRoot(popUpLabel);
		}
		Stage popUpStage = new Stage();
		view.makeDoesNotExistWindow(popUpStage, popUp1);
	}
	/**
	 * Pop up window created to show Admin they have successfully removed a course to the searched student's record
	 */
	public void courseRemovedWindow() {
		if (popUpLabel.getText().equals(
				"Course has been removed from student's SAIN") == false) {
			popUpLabel.setText("Course has been removed from student's SAIN");
			popUp1.setRoot(popUpLabel);
		}
		Stage popUpStage = new Stage();
		view.makeDoesNotExistWindow(popUpStage, popUp1);
	}

	// MainController sets student once SAIN report is clicked.
	public void setStudent(Student s) {
		myStudent = s;
	}

	public void setStaffValue(int i) {
		view.setStaffValue(i);
		// add button only appears if admin...
		if (i == 2)
			searchScreen.addStudent.setVisible(true);

	}

}
