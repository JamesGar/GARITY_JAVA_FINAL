package view;

import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * The view that users see. Gets various panes from facade that are then set
 * to the main screen.
 * 
 * @author James Garity
 *
 */
public class MainView {

	Pane pane = new Pane();
	int staffValue;
	
	/**
	 * 
	 * @param primaryStage - stage created in Main class.
	 */
	public MainView(Stage primaryStage) {

		Scene s = new Scene(pane, 740, 640);

		primaryStage.setScene(s);
		primaryStage.show();
	}

	public void makeDoesNotExistWindow(Stage popUpStage, Scene popUp) {
		popUpStage.setScene(popUp);
		popUpStage.show();

	}

	public void setStaffValue(int i) {
		staffValue = i;
	}

	public int getStaffValue() {
		return staffValue;
	}

	// One method for setting all different views.
	public void setNewView(Pane facadePane) {
		pane.getChildren().clear();
		pane.getChildren().add(facadePane);
	}

}
