package view;

import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
/**
 * 
 * @author James Garity
 *
 */
public class LoginScreen {
	Rectangle side = new Rectangle();
	GridPane grid = new GridPane();
	Label title = new Label("Login Screen");
	Button b1 = new Button("Login");
	TextField username = new TextField();
	TextField password = new TextField();
	SideOptions sideOptions = new SideOptions();
	Image titlePic = new Image("http://instsrv.sunysuffolk.edu/scccgold.gif");
	ImageView viewImage = new ImageView(titlePic);
	Button saveButton = new Button("Save");
	Button loadButton = new Button("Load");
	Label usernameLabel = new Label("Username:");
	Label passwordLabel = new Label("Password:");
	DropShadow shadow = new DropShadow();

	public LoginScreen() {

	}
	/**
	 * 
	 * @return grid containing all needed objects for Login Screen
	 */
	public GridPane getMyGrid() {
		side.setFill(Color.CORNFLOWERBLUE);
		side.setWidth(200);
		side.setHeight(1000);
		grid.setConstraints(side, 65, 0,30,30);
		grid.add(side, 65, 0);
		side.setDisable(true);
		grid.setVgap(10);
		grid.setHgap(10);
		grid.add(title, 8, 22);
		grid.add(usernameLabel,5,25);
		grid.add(username, 6, 25);
		grid.add(passwordLabel, 9, 25);
		grid.add(password, 10, 25);
		grid.add(b1, 8, 26);
		b1.setEffect(shadow);
		b1.setStyle("-fx-font: 22 arial; -fx-base: #3069c0;");
		saveButton.setEffect(shadow);
		loadButton.setEffect(shadow);
		saveButton.setStyle("-fx-font: 18 arial; -fx-base: #0c4aa9;");
		loadButton.setStyle("-fx-font: 18 arial; -fx-base: #0c4aa9;");
		grid.add(saveButton,70,28);
		grid.add(loadButton,70,29);
		grid.setConstraints(viewImage, 6, 0, 20, 20);
		grid.add(viewImage, 6, 0);
		
		return grid;
	}

	public Button getContinueButton() {
		return b1;
	}

	public String getUserName() {
		return username.getText();
	}

	public String getPassword() {
		return password.getText();
	}

}
