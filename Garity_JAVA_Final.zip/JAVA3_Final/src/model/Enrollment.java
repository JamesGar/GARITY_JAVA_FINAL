package model;

import java.io.Serializable;

	
/**
 * The Enrollment class serves to hold all of a student's course information in relation
 * to their major. Has several bags for the different areas a course can be in, such as
 * 'Currently Taking', 'Failed' or 'Required for Major'.
 * 
 * 
 * @author James Garity
 *
 */
public class Enrollment implements Serializable{


	CoursesFailedBag failedBag;
	CoursesTakenBag takenBag;
	CoursesNeededBag neededBag;
	CoursesCurrentBag currentBag;
	private String currentTerm;
	private String enteredTerm;
	private Major myMajor;
	/**
	 * 
	 * @param currentTerm
	 * @param enteredTerm
	 * @param totalCreditsTaken
	 */
	public Enrollment(String currentTerm, String enteredTerm,
			double totalCreditsTaken) {
		currentBag = new CoursesCurrentBag();
		failedBag = new CoursesFailedBag();
		takenBag = new CoursesTakenBag();
		neededBag = new CoursesNeededBag();
		this.currentTerm = currentTerm;
		this.enteredTerm = enteredTerm;
	}

	public CoursesFailedBag getFailedBag() {
		return failedBag;
	}

	public void setFailedBag(CoursesFailedBag failedBag) {
		this.failedBag = failedBag;
	}

	public CoursesTakenBag getTakenBag() {
		return takenBag;
	}

	public void setTakenBag(CoursesTakenBag takenBag) {
		this.takenBag = takenBag;
	}

	public CoursesNeededBag getNeededBag() {
		return neededBag;
	}

	public void setNeededBag(CoursesNeededBag neededBag) {
		this.neededBag = neededBag;
	}

	public String getNeededCourse(int i) {
		return neededBag.getCourse(i).toString();
	}

	public String getCurrentTerm() {
		return currentTerm;
	}

	public void setCurrentTerm(String currentTerm) {
		this.currentTerm = currentTerm;
	}

	public String getEnteredTerm() {
		return enteredTerm;
	}

	public void setEnteredTerm(String enteredTerm) {
		this.enteredTerm = enteredTerm;
	}

	public void setMyMajor(Major m) {
		myMajor = m;
	}

	public Major getMyMajor() {
		return myMajor;
	}

	public CoursesCurrentBag getCurrentBag() {
		return currentBag;
	}

	public void setCurrentBag(CoursesCurrentBag currentBag) {
		this.currentBag = currentBag;
	}

}
