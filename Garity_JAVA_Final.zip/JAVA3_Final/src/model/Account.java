package model;

import java.io.Serializable;
	/**
	 * 
	 * @author Conor
	 *
	 */
public class Account implements Serializable{

	private String username;
	private String password;

	// staffLevel is used to determine, when logging in, if the staff is Faculty
	// or Admin
	private int staffLevel;
	
	/**One constructor, without 'level' for student account
	 * 
	 * @param username
	 * @param password
	 */
	public Account(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	/**
	 * Another constructor for a staff account, including a level
	 * 
	 * @param username
	 * @param password
	 * @param level - 1 = faculty user; 2 = admin user
	 */
	public Account(String username, String password, int level) {
		this.username = username;
		this.password = password;
		staffLevel = level;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * 
	 * @param i - 1 = Faculty member. 2 = Admin user.
	 */
	public void setLevel(int i) {
		staffLevel = i;
	}

	public int getStaffLevel() {
		return staffLevel;
	}

}
