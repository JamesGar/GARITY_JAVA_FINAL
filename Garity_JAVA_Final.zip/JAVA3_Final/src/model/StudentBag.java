package model;

import java.util.ArrayList;
/**
 * Holds all the students on record for easy searching.
 * 
 * @author James Garity
 *
 */
public class StudentBag implements Bag {

	ArrayList<Student> studentList;

	public StudentBag() {

		studentList = new ArrayList<Student>();
	}

	@Override
	public void add(Object obj) {
		studentList.add((Student) obj);

	}

	@Override
	public void remove(int i) {
		studentList.remove(i);
	}
	public void removeAll(){
		for(int i = 0; i<studentList.size();i++){
			studentList.remove(i);
		}
	}
	

	public Student getStudent(int i) {
		return studentList.get(i);
	}
	
	/**
	 *search for student by last name
	 *
	 *@param i - id of student
	 */
	@Override
	public Object search(int i) {

		for (int j = 0; j < studentList.size(); j++) {
			if (studentList.get(j).getId() == i) {
				return studentList.get(j);
			}
		}

		return null;

	}
	/**
	 * Goes through student bag to see if the username and password given
	 * from login is equal to that of any student on record.
	 * 
	 * @param userName
	 * @param passWord
	 * @return - Student with a matching Username and Password value.
	 */
	public Student verify(String userName, String passWord) {
		for (int i = 0; i < studentList.size(); i++) {
			if (studentList.get(i).getAccount().getUsername().equals(userName)
					&& studentList.get(i).getAccount().getPassword()
							.equals(passWord))
				return studentList.get(i);
		}
		return null;
	}

	
	/**
	 * needed for when press 'add student' and check for new id given
	 * 
	 * @return the number of students on record.
	 */
	public int getSize() {
		return studentList.size();
	}
	
}
