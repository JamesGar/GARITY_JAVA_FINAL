package model;

public class ComputerScienceMajor extends Major{

	public ComputerScienceMajor(String myMajor, double majorGPA,
			double creditsTowardDegree, double minimumGPA,
			double totalCreditsRequired) {
		super(myMajor, majorGPA, creditsTowardDegree, minimumGPA, totalCreditsRequired);
		// TODO Auto-generated constructor stub
	}

}
