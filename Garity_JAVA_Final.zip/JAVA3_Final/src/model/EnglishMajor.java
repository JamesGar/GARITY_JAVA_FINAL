package model;

public class EnglishMajor extends Major {

	public EnglishMajor(String myMajor, double majorGPA,
			double creditsTowardDegree, double minimumGPA,
			double totalCreditsRequired) {
		super(myMajor, majorGPA, creditsTowardDegree, minimumGPA, totalCreditsRequired);
		// TODO Auto-generated constructor stub
	}

}
