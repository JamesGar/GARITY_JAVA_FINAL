package testers;

import static org.junit.Assert.*;

import java.util.ArrayList;

import model.Student;

import org.junit.Test;

public class StudentBagTest {

	@Test
	public void testSearch() {
		ArrayList<Student> studentList = new ArrayList<Student>();
		Boolean found = false;
		studentList.add(new Student());
		studentList.add(new Student());
		studentList.add(new Student());
		
		studentList.get(1).setFirstName("John");
		studentList.get(1).setId(5);
		
		for(int i = 0; i< studentList.size();i++){
			if(studentList.get(i).getId() == 5){
				found = true;
			}
		}
		
		assertTrue(found);
	}

	@Test
	public void testVerify() {
		ArrayList<Student> studentList = new ArrayList<Student>();
		Boolean found = false;
		studentList.add(new Student());
		studentList.add(new Student());
		studentList.add(new Student());
		
		studentList.get(1).getAccount().setUsername("test");
		studentList.get(1).getAccount().setPassword("password");
		
		for(int i = 0; i< studentList.size();i++){
			if(studentList.get(i).getAccount().getUsername().equals("test") && studentList.get(i).getAccount().getPassword().equals("password")){
				found = true;
			}
		}
		
		assertTrue(found);

	}

}
