package testers;

import static org.junit.Assert.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import model.Course;
import model.Major;
import model.MajorBag;
import model.Student;

import org.junit.Test;

public class MainControllerTest {

	
	@Test
	public void testNewSainButtonClicked() {
		MajorBag majorBag = new MajorBag();
		majorBag.add(new Major());
		majorBag.add(new Major());
		Student testStudent = new Student();
		testStudent.setMajorBag(majorBag);
		testStudent.setMajorID(0);

		ArrayList<Course> myCourses = new ArrayList<Course>();
		
		testStudent.getEnrollmentInfo().getTakenBag().add(new Course());
		testStudent.getEnrollmentInfo().getTakenBag().add(new Course());
		
		myCourses.add(testStudent.getEnrollmentInfo().getTakenBag().getCourse(1));
		majorBag.getMajor(0).getMajorCoursesBag().add(myCourses.get(0));
		
		assertTrue(majorBag.getMajor(0).getMajorCoursesBag().get(0).equals(testStudent.getEnrollmentInfo().getTakenBag().getCourse(1)));
	}

	@Test
	public void testWriteAndLoadSaveData() {
		File testFile = new File("saveTest.dat");
		Student testStudent = new Student();
		Student resultingStudent = new Student();
		try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(testFile))){
			out.writeObject(testStudent);
			
		} catch (IOException e) {
			fail("Not yet implemented");
		}
		
		try(ObjectInputStream in = new ObjectInputStream(new FileInputStream(testFile))){
			try {
				resultingStudent = (Student) in.readObject();
			} catch (ClassNotFoundException e) {
				
			}
		} catch (FileNotFoundException e) {
			
		} catch (IOException e) {
			
		}
		
		assertEquals(testStudent,resultingStudent);

	}

	

}
